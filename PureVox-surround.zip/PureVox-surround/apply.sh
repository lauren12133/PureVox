#!/usr/bin/env bash
# 把 PureVox-surround 合并进一份 PureVox 源码树（幂等，重复跑安全）。
# 用法：bash apply.sh [/path/to/PureVox-main]
#       不传参数 = 当前目录就是 PureVox 仓库根。
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-$(pwd)}"
TARGET="$(cd "$TARGET" && pwd)"

die() { printf '\033[31m✗ %s\033[0m\n' "$1" >&2; exit 1; }
ok()  { printf '\033[32m✓ %s\033[0m\n' "$1"; }
warn(){ printf '\033[33m! %s\033[0m\n' "$1"; }

# ---- 1. 确认目标是对的仓库 ----
[ -f "$TARGET/src-tauri/Cargo.toml" ] || die "找不到 $TARGET/src-tauri/Cargo.toml，路径不像 PureVox 仓库根"
grep -q 'name = "purevox"' "$TARGET/src-tauri/Cargo.toml" || die "src-tauri/Cargo.toml 里没有 name = \"purevox\"，目标不对"
ok "目标仓库：$TARGET"

# ---- 2. 拷文件（幂等：覆盖同名，保留其它） ----
mkdir -p "$TARGET/src-tauri/src/dsp/surround" "$TARGET/src-tauri/src/compat"
cp "$HERE"/src-tauri/src/dsp/surround/*.rs "$TARGET/src-tauri/src/dsp/surround/"
cp "$HERE"/src-tauri/src/compat/*.rs       "$TARGET/src-tauri/src/compat/"
ok "已写入 surround/（6 个文件）与 compat/（2 个文件）"

if [ -d "$TARGET/verify" ]; then
  warn "verify/ 已存在，跳过（想更新就手动删掉再跑）"
else
  cp -R "$HERE/verify" "$TARGET/verify"
  rm -rf "$TARGET/verify/target"
  ok "已写入 verify/（独立测试 crate）"
fi

# ---- 3. 插模块声明（幂等） ----
DSPMOD="$TARGET/src-tauri/src/dsp/mod.rs"
if grep -q '^pub mod surround;' "$DSPMOD"; then
  warn "dsp/mod.rs 已有 pub mod surround;，跳过"
else
  cat >> "$DSPMOD" <<'EOF'

/// 空间域：7.1 总线 → HRIR 卷积 → 双耳（P1 阶段仅由 `verify/` 独立 crate 覆盖，
/// 接入输出链后删掉下面的 `allow`）。
#[allow(dead_code)]
pub mod surround;
EOF
  ok "dsp/mod.rs 已注册 surround"
fi

MAIN="$TARGET/src-tauri/src/main.rs"
if grep -q '^mod compat;' "$MAIN"; then
  warn "main.rs 已有 mod compat;，跳过"
else
  # 插在第一条 mod 声明之后，保持和仓库一致的声明区位置
  awk 'BEGIN{done=0}
       {print}
       /^mod audio;[[:space:]]*$/ && !done {
         print ""
         print "/// 外部生态配置互操作（Equalizer APO `config.txt` / HeSuVi `hesuvi.txt`）。"
         print "/// P1 阶段仅由 `verify/` 覆盖，接入输出链后删掉下面的 `allow`。"
         print "#[allow(dead_code)]"
         print "mod compat;"
         done=1
       }' "$MAIN" > "$MAIN.tmp" && mv "$MAIN.tmp" "$MAIN"
  grep -q '^mod compat;' "$MAIN" || die "main.rs 里没找到 'mod audio;'，请手动把 mod compat; 加到声明区"
  ok "main.rs 已注册 compat"
fi

# ---- 4. 下一步 ----
cat <<'EOF'

合并完成。接下来：

  cd verify && cargo test          # 30 秒，48 个用例（不需要 Tauri / 声卡）
  cargo fmt -- --check && cargo clippy --all-targets -- -D warnings

全量门禁（需 tauri-cli 3.0.0-alpha.5 + Node 24）：

  python tools/automation/check.py -Gate clippy

跑起来：

  cd src-tauri && cargo tauri dev
EOF
