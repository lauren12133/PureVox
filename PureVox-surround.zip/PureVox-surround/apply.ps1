﻿# 把 PureVox-surround 合并进一份 PureVox 源码树（幂等，重复跑安全）。
# 用法：powershell -ExecutionPolicy Bypass -File apply.ps1 -Target C:\path\to\PureVox-main
param(
    [string]$Target = (Get-Location).Path
)

$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Utf8 = New-Object System.Text.UTF8Encoding($false)

function Fail($m) { Write-Host "x $m" -ForegroundColor Red; exit 1 }
function Ok($m)   { Write-Host "v $m" -ForegroundColor Green }
function Warn($m) { Write-Host "! $m" -ForegroundColor Yellow }

if (-not (Test-Path (Join-Path $Target "src-tauri\Cargo.toml"))) {
    Fail "$Target 下没有 src-tauri\Cargo.toml，路径不像 PureVox 仓库根"
}
if (-not (Select-String -Path (Join-Path $Target "src-tauri\Cargo.toml") -Pattern 'name = "purevox"' -Quiet)) {
    Fail "src-tauri\Cargo.toml 里没有 name = ""purevox""，目标不对"
}
Ok "目标仓库：$Target"

# ---- 1. 拷文件 ----
$dstSurround = Join-Path $Target "src-tauri\src\dsp\surround"
$dstCompat   = Join-Path $Target "src-tauri\src\compat"
New-Item -ItemType Directory -Force -Path $dstSurround, $dstCompat | Out-Null
Copy-Item (Join-Path $Here "src-tauri\src\dsp\surround\*.rs") $dstSurround -Force
Copy-Item (Join-Path $Here "src-tauri\src\compat\*.rs")       $dstCompat   -Force
Ok "已写入 surround\（6 个文件）与 compat\（2 个文件）"

$dstVerify = Join-Path $Target "verify"
if (Test-Path $dstVerify) {
    Warn "verify\ 已存在，跳过（想更新就先删掉再跑）"
} else {
    Copy-Item (Join-Path $Here "verify") $dstVerify -Recurse -Force
    Remove-Item (Join-Path $dstVerify "target") -Recurse -Force -ErrorAction SilentlyContinue
    Ok "已写入 verify\（独立测试 crate）"
}

# ---- 2. 插模块声明（幂等） ----
$dspMod = Join-Path $Target "src-tauri\src\dsp\mod.rs"
$s = [System.IO.File]::ReadAllText($dspMod, $Utf8)
if ($s -match '(?m)^pub mod surround;') {
    Warn "dsp\mod.rs 已有 pub mod surround;，跳过"
} else {
    $add = "`r`n/// 空间域：7.1 总线 → HRIR 卷积 → 双耳（P1 阶段仅由 verify/ 独立 crate 覆盖，`r`n/// 接入输出链后删掉下面的 allow）。`r`n#[allow(dead_code)]`r`npub mod surround;`r`n"
    [System.IO.File]::WriteAllText($dspMod, $s.TrimEnd() + $add, $Utf8)
    Ok "dsp\mod.rs 已注册 surround"
}

$main = Join-Path $Target "src-tauri\src\main.rs"
$m = [System.IO.File]::ReadAllText($main, $Utf8)
if ($m -match '(?m)^mod compat;') {
    Warn "main.rs 已有 mod compat;，跳过"
} else {
    $block = "mod audio;`r`n/// 外部生态配置互操作（Equalizer APO config.txt / HeSuVi hesuvi.txt）。`r`n/// P1 阶段仅由 verify/ 覆盖，接入输出链后删掉下面的 allow。`r`n#[allow(dead_code)]`r`nmod compat;"
    if ($m -notmatch 'mod audio;') { Fail "main.rs 里没找到 'mod audio;'，请手动把 mod compat; 加到声明区" }
    $m2 = [regex]::Replace($m, 'mod audio;', $block, 1)
    [System.IO.File]::WriteAllText($main, $m2, $Utf8)
    Ok "main.rs 已注册 compat"
}

Write-Host ""
Write-Host "合并完成。接下来：" -ForegroundColor Cyan
Write-Host "  cd verify; cargo test          # 30 秒，48 个用例（不需要 Tauri / 声卡）"
Write-Host "  cargo fmt -- --check; cargo clippy --all-targets -- -D warnings"
Write-Host ""
Write-Host "全量门禁（需 tauri-cli 3.0.0-alpha.5 + Node 24）："
Write-Host "  python tools/automation/check.py -Gate clippy"
Write-Host ""
Write-Host "跑起来："
Write-Host "  cd src-tauri; cargo tauri dev"
