# 合并 / 编译 / 测试

## 先看这个：你要走哪条路

| 你想干什么 | 需要什么 | 耗时 | 跳到 |
|---|---|---|---|
| **只想听效果**（确认这东西有用） | **什么都不用装**，解压后有现成 WAV | 1 分钟 | [§0](#0-只想听效果) |
| **自己生成 / 改参数** | Rust（**不需要 PureVox 源码**） | 3 分钟 | [§0.1](#01-装-rust已有就跳过) |
| **跑一遍测试**（确认代码正确） | 只要 Rust | 1 分钟 | [§3 档位 1](#档位-1只验-dsp30-秒推荐先跑这个) |
| **合并进源码**（准备提 PR / 自己改） | PureVox 源码 + Rust | 10 分钟 | [§1](#-拿到-purevox-源码) → [§2](#-合进去) |
| **编译出完整 app 看界面** | 完整工具链 + Windows 声卡 | 30 分钟+ | [§3 档位 3](#档位-3真的跑起来看界面) |

> **关键**：`demo/` 是预生成的音频，`verify/` 是独立 crate（`#[path]` 直接引用同一个
> `src-tauri/src/dsp/surround/*.rs`）。所以你**解压这个 zip 就能听、能编译、能测试**，
> 一行 PureVox 源码都不用下。

---

## 0. 只想听效果

### 0.0 连 Rust 都不用装

解压后直接打开 **`demo/`** 目录，里面已经有 4 个生成好的 WAV 和一份 `README.txt`：

```
demo/01_单声道_全部0dB_基准.wav
demo/02_单声道_后方+12dB.wav
demo/03_单声道_前方-18dB.wav
demo/04_真7.1_只有后左.wav
```

**戴耳机**，按 `01 → 02 → 03` 顺序听。02 应该只有后方变响、正前方纹丝不动，
这就是"单独调各方向音量"。听不出来再看 `demo/README.txt` 里"听到/听不到说明什么"。

想自己改参数重新生成（比如把 +12 dB 改成 +6 dB）再往下走。

### 0.1 装 Rust（已有就跳过）

```bash
# Windows：去 https://rustup.rs 下 rustup-init.exe，下一步下一步
# 或者 PowerShell：
winget install Rustlang.Rustup

# Linux / macOS：
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

装完**关掉终端重开**，验证：

```bash
rustc --version    # 需要 >= 1.75（verify/ 是 edition 2021，比主仓库的 1.95 宽松）
cargo --version
```

> 第一次 `cargo` 命令会联网从 crates.io 拉 `rustfft`（约 1 MB，5 个间接依赖）。
> 公司网/校园网拉不动就设镜像（见文末排错表最后一条）。

### 0.2 解压 → 跑演示 → 听

```bash
# 解压（Windows 右键"全部解压缩"也行）
unzip PureVox-surround.zip
cd PureVox-surround/verify

# 生成 4 个 WAV 到 ./audition_out
cargo run --release --bin audition -- ./audition_out
```

预期输出：

```
合成 HRIR：512 抽头，Woodworth 球头模型（不是测量数据）
处理块长：128 样本 / 2.67 ms
信号：7.5 s 脚步声，全局峰值 0.6187，统一缩放 1.439

  01_单声道_全部0dB_基准.wav              RMS   -38.7 dBFS
  02_单声道_后方+12dB.wav               RMS   -33.7 dBFS
  03_单声道_前方-18dB.wav               RMS   -44.3 dBFS
  04_真7.1_只有后左.wav                 RMS   -40.4 dBFS
```

**戴耳机**（必须耳机，音箱听不出双耳差异），打开 `audition_out/`，按这个顺序听：

| 对比 | 该听到什么 | 如果听不到说明什么 |
|---|---|---|
| 01 → 02 | 后方脚步**变近变响**，正前方完全没动 | 若整体都变响 → 增益加错了位置（加在卷积之后了） |
| 01 → 03 | 前方退远、整体变闷，**后方没有变响** | 若后方也变闷 → 每声道增益没生效，成了总音量 |
| 01 vs 04 | 04 的方向更"实"，01 散在四周 | 这正说明"真 7.1 源"和"单声道上混"的区别 |

基准文件偏轻是**故意的**：四个文件用同一个缩放系数，否则归一化会把增益差抹平。
听之前把系统音量调到 60% 左右。

### 0.3 顺手看一眼延迟和 CPU

```bash
cargo run --release --bin latency_plan   # 你关心的 45 ms 是怎么算出来的
cargo run --release --bin bench_rt       # 块长 64/128/480 各吃多少 CPU
```

---

## ① 拿到 PureVox 源码

> 只有走"合并进源码"这条路才需要往下读。只想听效果 / 跑测试的，直接跳 §0。

三个动作，全程离线可控：**① 拿源码 → ② 合进去 → ③ 跑测试**。
第 ③ 步有两种档位：只验 DSP（30 秒，不需要 Tauri、不需要声卡、不需要联网）和全量门禁（需要完整工具链）。

---

## ① 拿到 PureVox 源码

选一个能通的入口，**效果完全一样**（都是 `main` 分支最新代码）：

| 方式 | 地址 | 说明 |
|---|---|---|
| 网页下载 zip | `https://github.com/a2heng/PureVox/archive/refs/heads/main.zip` | 浏览器直接点，最快 |
| codeload（直连） | `https://codeload.github.com/a2heng/PureVox/zip/refs/heads/main` | 仓库大（约 180 MB），直连常断 |
| 加速镜像 A | `https://ghfast.top/https://github.com/a2heng/PureVox/archive/refs/heads/main.zip` | 前面拼前缀即可，命令见下 |
| 加速镜像 B | `https://gh-proxy.com/https://github.com/a2heng/PureVox/archive/refs/heads/main.zip` | 同上，另一家 |
| Releases | `https://github.com/a2heng/PureVox/releases` | **是安装包不是源码**，别下错 |

命令行（curl 断点续传，断了重跑同一条命令即可）：

```bash
# 直连
curl -L -C - -o PureVox.zip https://github.com/a2heng/PureVox/archive/refs/heads/main.zip

# 直连慢/断 → 换镜像（两个都失败再换第三个域名）
curl -L -C - -o PureVox.zip https://ghfast.top/https://github.com/a2heng/PureVox/archive/refs/heads/main.zip
curl -L -C - -o PureVox.zip https://gh-proxy.com/https://github.com/a2heng/PureVox/archive/refs/heads/main.zip

# 解压（Windows 用资源管理器右键解压到当前文件夹即可）
unzip -q PureVox.zip && cd PureVox-main
```

> 解压出来的目录名是 `PureVox-main`，**没有 `.git`**。后面要用 `git apply` 的话先 `git init`（见 ②-A 末尾）。
> 想要带历史的克隆：`git clone --depth 1 https://github.com/a2heng/PureVox`（镜像同理加前缀）。

---

## ② 合进去

两种方式产物一致（19 个文件、+3085 行）。**A 更安全**（能先看 diff 再决定），B 更省事。

### A. 打补丁（推荐）

```bash
cd PureVox-main
git init -q && git add -A && git commit -qm "upstream"   # 没有 .git 时才需要这两行

git apply --check patch/*.patch   # 先干跑，不写盘
git apply         patch/*.patch   # 真打
git status        # 应看到 4 个修改/新增：compat/、dsp/surround/、dsp/mod.rs、main.rs、verify/
```

想保留提交信息用 `git am patch/0001-*.patch`（效果一样，多一个 commit）。

### B. 脚本拷贝

```bash
# Linux / macOS
bash apply.sh /path/to/PureVox-main

# Windows PowerShell
powershell -ExecutionPolicy Bypass -File apply.ps1 -Target C:\path\to\PureVox-main
```

两个脚本都是**幂等**的：重复跑不会重复插声明。

### 合进去改了什么（19 个文件 / +3085 行）

| 文件 | 动作 |
|---|---|
| `src-tauri/src/dsp/surround/*.rs`（7 个） | 新增：空间域内核 + 延迟预算（`latency.rs`） |
| `src-tauri/src/compat/{mod,apo}.rs` | 新增：APO 配置互操作 |
| `src-tauri/src/dsp/mod.rs` | +4 行：`pub mod surround;`（带 `#[allow(dead_code)]`） |
| `src-tauri/src/main.rs` | +4 行：`mod compat;`（同上） |
| `verify/`（新 crate） | 独立验证壳 + 三个 bin（`bench_rt` / `latency_plan` / `audition`），不参与 app 构建 |

**两处 `#[allow(dead_code)]` 是临时脚手架**：P1 只交付 DSP 层，还没接进输出链，不加这个仓库的
`clippy -D warnings` 会直接红。P2 把 `spatial_output` 接进 `session.rs` 之后删掉这两行即可（`PATCH.md` 里有对应位置）。

---

## ③ 测试

### 档位 1：只验 DSP（30 秒，推荐先跑这个）

```bash
cd verify
cargo test
```

预期输出（已在你这份代码上跑过）：

```
running 48 tests
test result: ok. 48 passed; 0 failed; 0 ignored
```

这个 crate 只依赖 `rustfft`，不需要 Tauri、不需要声卡、不需要模型文件，**笔记本上冷编译约 20 秒**。
两个 bin 可以先看效果，不用等 UI：

```bash
cargo run --release --bin latency_plan              # 打印延迟预算表（47 → 32 → 24.7 → 13.7 → 11 ms）
cargo run --release --bin bench_rt                  # 打印块长 64/128/480 的真实 CPU 占用
cargo run --release --bin audition -- ./audition_out  # 生成 4 个 WAV，戴耳机听（见下）
```

#### 用耳朵验证：`audition`

单元测试只能证明"数值上 BL 静音后其余通道不变"，证明不了"听起来确实只在后方变化"。
`audition` 用同一段 7.5 秒脚步声过四遍空间化，写出四个 WAV：

| 文件 | 相对基准 | 该听到什么 |
|---|---|---|
| `01_单声道_全部0dB_基准.wav` | — | 声音散在四周（单声道上混的必然结果） |
| `02_单声道_后方+12dB.wav` | 只抬 BL/BR | **后方变近，正前方纹丝不动** |
| `03_单声道_前方-18dB.wav` | 只压 FL/FR | 前方退远、整体变闷，**后方没有变响** |
| `04_真7.1_只有后左.wav` | 8 路源只有 BL | 方向更实、不散（真方位 vs 编出来的方位） |

四个文件用**同一个缩放系数**写盘 —— 分别归一化会把增益差抹平，那就什么都听不出来了。
所以基准文件偏轻是正常的，听之前先把系统音量调大。

里面的 HRIR 是 Woodworth 球头模型合成的（ITD + 头影低通），**不是任何商业 HRTF 的测量数据**，
方位精细度不如 HeSuVi / Dolby，但"哪个方向变响了"足够清楚。
它用 `#[path]` 直接引用 `src-tauri/src/dsp/surround/*.rs` 的同一份文件，不存在"测试通过但交付代码不一样"的漂移。

顺手把格式与 lint 也过一遍（用的是仓库自己的 `rustfmt.toml`）：

```bash
cd verify
cargo fmt -- --check                                    # 应无输出
cargo clippy --all-targets -- -D warnings                # 应与 CI 同参数，0 告警
```

### 档位 2：仓库门禁（需要完整工具链）

先装工具链（版本以 `tools/automation/versions.env` 为准）：

```bash
# Rust：Cargo.toml 要求 rust-version = "1.95"，用 stable 即可
rustup toolchain install stable --component rustfmt --component clippy
rustup default stable
rustc --version

# tauri-cli：仓库钉死 3.0.0-alpha.5，版本不对 `cargo tauri` 直接不认
cargo install tauri-cli --version 3.0.0-alpha.5 --locked

# Node 24（只有 tsc 类型检查 + i18n 门禁需要）与 Python 3（门禁脚本）
node -v && python3 -V
```

然后按单项跑（CI 就是这么拆的，报错好定位）：

```bash
python tools/automation/check.py -Gate fmt
python tools/automation/check.py -Gate clippy
python tools/automation/check.py -Gate test
python tools/automation/check.py -Gate build
```

一次跑全部：`python tools/automation/check.py`（会依次跑 fmt/clippy/build/test/ui/version/bundle，比较慢）。

> `check.py` 里所有 `cargo` 命令都在 `src-tauri/` 下执行，你不需要手动 `cd`。

### 档位 3：真的跑起来看界面

```bash
cd src-tauri
cargo tauri dev
```

首次编译会联网下载 `onnxruntime`（`ort` 的 `download-binaries`），**这一步最容易卡**，见下面排错表第 4 条。

---

## 排错表（都是这套工具链的真实坑）

| 现象 | 原因 | 处理 |
|---|---|---|
| `error: no matching package named 'tauri-build'` / 一堆 alpha 版本解析失败 | `edition = "2024"` + `rust-version = "1.95"`，工具链太旧 | `rustup update stable`，确认 `rustc >= 1.95` |
| `cargo tauri: no such command` | tauri-cli 版本不是 3.0 alpha | `cargo install tauri-cli --version 3.0.0-alpha.5 --locked --force` |
| Linux 上 `webkit2gtk` 找不到 | 缺系统库 | `sudo apt install libwebkit2gtk-4.1-dev libssl-dev libayatana-appindicator3-dev librsvg2-dev`（Ubuntu 24.04） |
| Windows 上 `link.exe not found` | 没装 MSVC Build Tools | 装 VS Build Tools 勾「使用 C++ 的桌面开发」，再装 WebView2 Runtime |
| 卡在下载 onnxruntime / 编译 `ort-sys` | `download-binaries` 走 GitHub | 设代理再编：`set HTTPS_PROXY=http://127.0.0.1:7890`（PowerShell 用 `$env:HTTPS_PROXY=...`） |
| `apply` 报 `patch does not apply` | 源码不是最新 `main`，或已手动改过 `dsp/mod.rs` / `main.rs` | 换 **B 脚本方式**（只拷文件 + 幂等插声明），或 `git apply --3way` |
| clippy 报 `dead_code` | 有人把 `#[allow(dead_code)]` 删了但还没接输出链 | 保留那两行，等 P2 |
| `verify` 里 `file not found for module` | 缺 `verify/src/dsp/`、`verify/src/compat/` 两个空目录（`#[path]` 基准目录） | 补上两个目录（里面有 `.gitkeep`），或直接 `cargo test` 前先 `ls verify/src` 确认 |

---

## 回滚

```bash
# 用补丁合的
git checkout -- src-tauri/src/dsp/mod.rs src-tauri/src/main.rs
rm -rf src-tauri/src/dsp/surround src-tauri/src/compat verify
# 用脚本合的：同上三条命令（脚本只新增文件 + 改上面两个文件）
```

---

## 关于 `verify/` 要不要提交

它是**离线验证用的一次性脚手架**，不参与 `src-tauri` 构建（独立 crate，不在任何 workspace 里）。
提 PR 时建议：要么删掉，要么挪到 `tools/surround-verify/` 并同步改 `#[path]` 的相对层级（这会从 `../../../` 变成 `../../../../`）。
