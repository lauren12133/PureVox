//! 独立验证壳：把 `src-tauri/src/` 下的**同一份文件**装进一个不依赖 Tauri 的 crate，
//! 只补上两个常量，就能在本机 `cargo test` 跑通 L1 DSP 层。
//!
//! 这样"交付的代码"和"跑测试的代码"是同一份，不存在复制粘贴漂移。

pub mod audio {
  pub const SAMPLE_RATE: u32 = 48_000;
  pub const HOP: usize = (SAMPLE_RATE / 100) as usize;
}

pub mod dsp {
  #[path = "../../../src-tauri/src/dsp/surround/mod.rs"]
  pub mod surround;
}

pub mod compat {
  #[path = "../../../src-tauri/src/compat/apo.rs"]
  pub mod apo;
}
