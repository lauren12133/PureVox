# 集成补丁（P1 → P2）

目标仓库：`a2heng/PureVox`（Rust 1.95 / Tauri 3 alpha / GPL-3.0。）

新增文件直接按同路径复制；下面按改动顺序列出**现有文件**要加的代码，每处都给了锚点
（函数名 / 现有代码行），照着插即可。

> 说明：§1 全部经过本机 `cargo test` + `clippy -D warnings` + `fmt --check` 验证；
> §2 起涉及 `playback` / `mixer` / `session` / UI，**本机无法编译**（要 Tauri 3 alpha 工具链、
> Windows 声卡、`models/*.onnx`），因此按"设计 + 代码块"给出，标注了需要真机验证的点。

---

## 0. 两行模块声明

```rust
// src-tauri/src/dsp/mod.rs  ── 现有列表末尾追加
pub mod surround;

// src-tauri/src/main.rs      ── 现有 mod 声明区追加
mod compat;
```

`main.rs` 是 crate 根（仓库没有 `lib.rs`），所以 `compat` 与 `dsp` 同级。

---

## 1. 先改文档：不变式要扩一条

仓库纪律是"实现与文档冲突时以文档为准"，所以先补两处文档再动代码。

`ARCHITECTURE.md` §2（数据单位与不变量）追加：

```markdown
- **多声道只到输出汇为止**：处理域恒为 F32 单声道 480；输出行可以声明
  `Sink::Stereo`（2×480，交错 L/R），由 `dsp::surround` 从单声道派生。
  **任何处理行（Stage）永远看不到多声道**，`Stage::process` 的签名不变。
- 同一个输出设备上**不允许混用**不同 `Sink`（mono 行 + stereo 行 = 规划期报错，
  不做隐式上混）：混了以后"哪一路是左耳"就没有单一答案了。
```

`PLUGINS.md` 节点清单增加一行（输出类）：

```markdown
| `spatial_output` | 虚拟环绕输出（7.1→双耳） | 输出 | `hrir` `settings` `gains` `delays` `upmix` `spread` `makeup_db` |
```

---

## 2. `audio/playback.rs`：让汇支持 2 声道

### 2.1 现状

```rust
pub fn spawn(hub: SharedHub, device_id: String, source: Arc<Fanout>, tag: String)
    -> Result<WorkerHandle, String>
```

回调把单样本复制进所有声道（`build_stream`）。这是"单声道复制"，`channels` 只影响
`chunks_exact_mut(ch)` 的行宽。

### 2.2 新增汇类型

```rust
/// 汇（输出行）的声道数。`Mono` = 现状；`Stereo` = 空间域双耳输出。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Sink {
  Mono,
  Stereo,
}

impl Sink {
  /// 环形缓冲里每个"帧"占的 f32 数。
  pub fn stride(self) -> usize {
    match self {
      Sink::Mono => 1,
      Sink::Stereo => 2,
    }
  }
}
```

### 2.3 签名与回调

```rust
pub fn spawn(
  hub: SharedHub,
  device_id: String,
  source: Arc<Fanout>,
  tag: String,
  sink: Sink,               // ← 新增参数；现有调用点传 Sink::Mono
) -> Result<WorkerHandle, String>
```

`build_stream` 增加 `stride`：

```rust
fn build_stream<T>(
  dev: &cpal::Device,
  cfg: &StreamConfig,
  mut cons: Consumer<f32>,
  stride: usize,
  stats: Arc<CallbackStats>,
  primed: Arc<AtomicBool>,
) -> Result<cpal::Stream, String>
where
  T: SizedSample + FromSample<f32>,
{
  let dev_ch = cfg.channels.max(1) as usize;
  let err_stats = stats.clone();
  dev.build_output_stream::<T, _, _>(
    *cfg,
    move |data: &mut [T], _info| {
      stats.on_block((data.len() / dev_ch) as u32);
      let mut silent = 0u64;
      for f in data.chunks_exact_mut(dev_ch) {
        if stride == 1 {
          let s = match cons.pop() {
            Ok(v) => v,
            Err(_) => { silent += 1; 0.0 }
          };
          let v = <T as FromSample<f32>>::from_sample_(s);
          for x in f.iter_mut() { *x = v; }
        } else {
          // 交错 L,R：设备只有 1 个声道时**下混**，绝不拿左声道冒充
          let l = cons.pop().unwrap_or_else(|_| { silent += 1; 0.0 });
          let r = cons.pop().unwrap_or_else(|_| { silent += 1; 0.0 });
          if dev_ch == 1 {
            let v = <T as FromSample<f32>>::from_sample_(0.5 * (l + r));
            for x in f.iter_mut() { *x = v; }
          } else {
            f[0] = <T as FromSample<f32>>::from_sample_(l);
            f[1] = <T as FromSample<f32>>::from_sample_(r);
            // 第 3 声道起写 0：5.1/7.1 耳机端点的其余声道由 HRIR 已经算进 L/R，
            // 再复制一遍等于把双耳声糊成"每个喇叭都在放同一段"
            for x in f[2..].iter_mut() { *x = 0.0; }
          }
        }
      }
      if silent > 0 && primed.load(Relaxed) {
        stats.xruns.fetch_add(silent, Relaxed);
      }
    },
    move |e| err_stats.on_error(e.to_string()),
    None,
  )
  .map_err(|e| format!("打开输出流失败：{e}"))
}
```

`run()` 里三处跟着改（锚点：`let conv = Converter::new(SAMPLE_RATE, cfg.sample_rate, HOP, true)?;`）：

```rust
// 1) 每只耳一个重采样器（比例由伺服统一下发，两条必然一致）
let mut convs: Vec<Converter> = (0..sink.stride())
  .map(|_| Converter::new(SAMPLE_RATE, cfg.sample_rate, HOP, true))
  .collect::<Result<_, _>>()?;
let dev_cap = cfg.sample_rate as usize * DEVICE_RING_MS / 1000
  + convs[0].output_frames_max() * sink.stride();
let (prod, cons) = RingBuffer::<f32>::new(dev_cap);

// 2) 填设备环：逐声道转换后交错入环
if let Ok(c) = src.read_chunk(HOP) {
  let (a, b) = c.as_slices();
  hop[..a.len()].copy_from_slice(a);
  hop[a.len()..].copy_from_slice(b);
  c.commit_all();
}
// 空间域：右耳 = 左耳重采样器 + 同一比例；两个 Converter 状态独立
let mut frames: Vec<Vec<f32>> = Vec::with_capacity(convs.len());
for cv in convs.iter_mut() {
  match cv.process(&hop) {
    Ok(out) => frames.push(out.to_vec()),
    Err(e) => { worker_error = Some(e); break; }
  }
}
if frames.len() == convs.len() {
  let n = frames[0].len();
  for i in 0..n {
    for f in &frames {
      let _ = dev_prod.push(f[i]);
    }
  }
}

// 3) 伺服 / 探针里的 ms↔样本换算全部乘 stride（device_buffer_ms、buffer_level_ms）
```

**必须真机验证的两个点**：
① 双 Converter 的相位/延迟是否一致（同一输入、同一比例，理论上逐样本一致；
若不一致说明 `Converter` 有内部随机初始化）；② 立体声下伺服仍要稳在 100 hop/s。

---

## 3. `audio/mixer.rs` + `device_pool.rs`：按 stride 混合

`Mixer::spawn(out, tag)` 现在按"样本"做对齐与相加。交错立体声的相加**在数学上完全一样**
（L,R,L,R… 逐样本相加 = 两路各自相加），所以只需要：

```rust
impl Mixer {
  pub fn spawn(out: Arc<Fanout>, tag: String, stride: usize) -> Result<Mixer, String> { … }
}
```

并把它内部所有 `样本数 → 毫秒` 的换算除以 `stride`（水位、容量、丢最旧）。
`device_pool` 里"同一设备一条混音"的键要补上 stride，并在规划期拒绝同设备混用
（见 §6 校验）。

---

## 4. `engine/registry.rs`：登记新输出节点

```rust
  // 输出行（汇）
  NodeSpec {
    ptype: "audio_output",
    label: "扬声器",
    kind: NodeKind::Output,
    params: &[],
  },
  // ↓ 新增
  NodeSpec {
    ptype: "spatial_output",
    label: "虚拟环绕输出（7.1→双耳）",
    kind: NodeKind::Output,
    params: &[
      // HRIR 文件（16 声道 WAV）；空 = 未配置，行显"未配置"而不是报错
      ParamSpec { key: "hrir", label: "HRIR", kind: ParamKind::Text { default: "" } },
      // 每声道增益/延时与 APO 导入结果都序列化在这一格，跟 eq31 的 settings 同一套做法
      ParamSpec { key: "settings", label: "空间参数", kind: ParamKind::Text { default: "" } },
      ParamSpec {
        key: "upmix",
        label: "上混",
        kind: ParamKind::Choice {
          default: "front",
          options: &[("front", "前左/前右"), ("center", "中置"), ("wide", "铺满房间")],
        },
      },
      ParamSpec {
        key: "spread", label: "扩散", kind: ParamKind::Number { lo: 0.0, hi: 1.0, default: 0.5, step: 0.05 },
      },
      ParamSpec {
        key: "makeup_db", label: "补偿(dB)", kind: ParamKind::Number { lo: -24.0, hi: 12.0, default: 0.0, step: 0.5 },
      },
    ],
  },
```

热参数（改它**不重建会话**，拖推子才不卡 —— `is_hot` 的判据见该函数注释）：

```rust
pub fn is_hot(ptype: &str, key: &str) -> bool {
  matches!(
    (ptype, key),
    ("gain", "gain_db")
      | ("loopback", "volume_db")
      | ("agc", "target_db")
      | ("agc", "speed")
      | ("agc", "floor_db")
      | ("eq31", "settings")
      | ("spatial_output", "settings")   // ← 8 个增益 + 8 个延时都在这里
      | ("spatial_output", "spread")
      | ("spatial_output", "makeup_db")
  )
}
```

> `hrir` / `upmix` **不是**热参数：前者要重建卷积器，后者改变信号怎么铺，
> 都必须走 `apply_plan`。

---

## 5. `engine/session.rs`：输出行接入

### 5.1 `Row` 增加字段

```rust
struct Row {
  // …现有字段…
  /// 空间域（`spatial_output` 行专用）：本行一份，状态不共享
  spatial: Option<crate::dsp::surround::Spatial>,
  /// 本行的汇类型（mono / stereo），供设备池与调试接口读
  sink: crate::audio::playback::Sink,
}
```

初始化处（`let mut row = Row { … }`）补 `spatial: None, sink: Sink::Mono`。

### 5.2 构建分支（锚点：`RowKind::Output => match device {`）

```rust
RowKind::Output if r.ptype == "spatial_output" => {
  // 1) HRIR：文件 → wav::parse → Hrir::from_wav（采样率/声道数不符在这里报人话）
  let hrir_path = r.params.get("hrir").cloned().unwrap_or_default();
  let hrir = match std::fs::read(&hrir_path) {
    Err(e) => Err(format!("读取 HRIR 失败（{hrir_path}）：{e}")),
    Ok(bytes) => crate::dsp::surround::wav::parse(&bytes)
      .and_then(|w| crate::dsp::surround::Hrir::from_wav(&w, &hrir_path)),
  };
  match hrir {
    Err(e) => row.error = Some(e),
    Ok(mut hrir) => {
      hrir.normalize_peak(1.0);              // 不同来源 HRIR 电平差极大，切预设不该跳音量
      let setup = crate::dsp::surround::SurroundSetup::default(); // 参数由 settings 解析
      row.spatial = Some(crate::dsp::surround::Spatial::new(hrir, setup.params));
      row.sink = Sink::Stereo;
      match device {
        None => row.unconfigured = true,
        Some(dev) => {
          row.label = format!("{}（7.1→双耳）", crate::devices::display_name(dev, false)
            .unwrap_or_else(|| dev.to_string()));
          row.device = Some(dev.to_string());
          row.pooled_output = true;
          // 池里的租约要按 Stereo 申请（§3）
          crate::engine::session::apply_output_lease(&mut row, hub, idx, ri);
        }
      }
    }
  }
}
```

### 5.3 每 hop 推送（锚点：`RowKind::Output => { … f.push_hop(&acc); }`）

```rust
RowKind::Output => {
  poll_output_lease(r, &hub, idx, ri, tick_start);
  if r.enabled {
    match (r.spatial.as_mut(), r.output.as_ref()) {
      // 空间域：单声道 acc → 双耳 → 交错 2×480 入扇出
      (Some(sp), Some(f)) => {
        let mut l = [0.0f32; HOP];
        let mut rr = [0.0f32; HOP];
        sp.process(&acc, &mut l, &mut rr);
        for i in 0..HOP {
          f.push_sample(l[i]);
          f.push_sample(rr[i]);
        }
      }
      (None, Some(f)) => f.push_hop(&acc),
      _ => {}
    }
  }
  if r.net_output {
    crate::net::hub().push_tx_hop(&acc);
  }
}
```

> `Fanout::push_hop` 之外需要一个 `push_sample`（或 `push_hop_interleaved(&[f32])`）
> —— 现有 `push_hop` 是"整 hop 进、整 hop 出"的单声道契约，加一个 2 倍长的交错版本即可，
> 丢弃策略（环满丢整个 hop）保持不变。

### 5.4 调试接口

`StreamInfo` 里 `channels` 已经存在（设备声道数），另外给空间行补三项（`DEBUG.md`
的"看不见的状态等于不存在"）：

```rust
spatial: Some(SpatialInfo {
  hrir: sp.hrir_name().to_string(),
  taps: sp.hrir_taps(),
  macs_per_hop: sp.macs_per_hop(),          // 8×2×parts×960
  per_channel_peak_dbfs: [f32; 8],          // 8 条通道各自的电平（雷达图直接用）
  ear_balance_db: [f32; 8],                 // HRIR 自身的方向线索（装错了这里能看出来）
}),
```

---

## 6. `plan.rs`：规划期校验（新增三条 `problems`）

```rust
// 1) 同一设备上不允许混用汇类型
//    （mono 行 + stereo 行 ⇒ "哪一路是左耳"没有单一答案）
// 2) spatial_output 必须配置 HRIR，否则该行 unconfigured
// 3) HRIR 采样率必须 = SAMPLE_RATE（48000），不一致直接挡在启动前，
//    而不是让用户听到"音调不对"再回来查
```

---

## 7. 界面（`ui/spatial.js` + i18n）

输出行下拉里出现"虚拟环绕输出（7.1→双耳）"后，行内展开一块面板：

```
┌ 虚拟环绕 ─────────────────────────────┐
│   [雷达图 300×300]      FL  ───●───  0.0 dB  [M] │
│   ● 8 个方向 = 8 个推子  FR  ──●────  0.0 dB  [M] │
│   半径 ∝ 该方向增益      FC  ────●── -3.0 dB  [M] │
│                          LFE ─●───── -12.0 dB [M] │
│                          BL  ─────●─ +6.0 dB  [M] │
│                          …                        │
│   HRIR: [atmos.wav      ] [浏览] [试听扫场]        │
│   上混: [前左/前右 ▾]  扩散 ──●── 0.5             │
│   [导入 config.txt]  [导出]  ⚠ 3 条不支持的指令…   │
└───────────────────────────────────────────────────┘
```

- 推子 = `HotSink`（`settings` 热参数），拖动 **不重建会话**（`is_hot` 已登记）。
- 「导入 config.txt」= `compat::apo::parse` → 写 `settings` + 弹 `warnings` 列表
  （**必须显示**：APO 配置里必然有我们不支持的行）。
- 「导出」= `compat::apo::export`，让用户随时能回到 APO/HeSuVi 继续折腾。
- i18n：`ui/i18n.js` 增 `spatial.*` 键；`tools/automation/i18n_lint.js` 会卡未翻译项。
- 雷达图的半径映射与 `Speaker::azimuth_deg()` 同源（`dsp/surround/layout.rs`），
  界面不另写一份角度表。

---

## 8. 许可与文档

- `LICENSE-THIRD-PARTY.txt` 加一条：**HRIR 为测量数据，商业算法（Dolby/DTS/…) 的 HRIR
  不随本项目分发**，仅支持用户自行导入。
- `DEBUG.md` 补 `spatial_output` 的探针字段（§5.4）。
- `IDEAS.md` 里"8 声道 loopback 采集"从设想转为待办（见 §10）。

---

## 9. 验收清单

P2 合并前必须全部为真：

- [ ] `cargo test`：现有用例 + `dsp::surround` 30 项全绿
- [ ] `cargo clippy --all-targets -- -D warnings` 零告警（含 `--all-targets`）
- [ ] `cargo fmt --check` 通过（2 空格 / 100 列）
- [ ] 1 kHz 测试音 → 双耳电平差 < 0.5 dB（HRIR 对称性）
- [ ] `BL/BR` 推子拉到 -30 dB 后，后左/后右方位明显变弱，**其余方向电平不变**（±0.5 dB）
- [ ] 端到端延迟**不增加**：卷积 0 延迟（输出块 n 对齐 `n*480`），只有滤波器的群延迟
- [ ] 100 hop/s 稳定（`hop/s` 字段不掉到 96，否则就是 §3 的 stride 换算漏了）
- [ ] 8 路满增益时 `peak_dbfs ≤ -1 dBFS`（不留 headroom 必削波，削波会毁掉方向线索）

## 10. 未决问题（需要真机/实测才能定）

| # | 问题 | 影响 | 怎么解 |
| --- | --- | --- | --- |
| 1 | **HeSuVi 的 `hrir/*.wav` 真实声道排布**（8 声道 vs 16 声道、谁对谁） | 决定 `compat::hesuvi` 能否一键导入 | 拿一个真实 HRIR 包，用冲激法测：`Speaker::ALL` 逐个放冲激，看哪个声道先响、两耳差多少 |
| 2 | **VB-Cable 是否真的暴露 8 声道端点** | 决定"PureVox → 虚拟声卡 8ch 直通"这条路是否成立 | Windows 上 `devices.rs` 枚举看 `channels`，或 WASAPI `GetMixFormat` |
| 3 | **loopback 采集是下混单声道**（`capture.rs`） | 现在只能"假 7.1"，不是真方位 | P2+：WASAPI loopback 保留 8 声道 → 直接喂 `Spatial::process_planar` |
| 4 | 双 `Converter` 的样本级一致性 | 立体声相位 | 合并前用现有 `clock_probe` 实测一对 Converter 的差异 |
