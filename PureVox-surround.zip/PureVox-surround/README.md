# PureVox · 输出侧虚拟 7.1（需求 1）

把 **VB-Cable / Equalizer APO / HeSuVi / EQ** 这套外挂链路收进 PureVox 的**输出部分**，
让"单独调各方向音量"成为一个普通输出行的内置能力。

> **想先听效果 → `demo/` 目录**：解压后直接有 4 个生成好的 WAV（连 Rust 都不用装），戴耳机听
> `01 → 02` 就能听出"只抬后方两个方向、正前方纹丝不动"。说明见 `demo/README.txt`。
>
> **怎么合进去 → [`MERGE.md`](MERGE.md)**（下载入口 / 打补丁或跑脚本 / 编译 / 测试 / 排错，一条龙）。
>
> 本目录是可直接落进 `a2heng/PureVox` 的新增文件 + 集成补丁。`PATCH.md` 是 P2–P4 的
> 逐处锚点与代码（要改现有文件的那部分），P1 的落盘改动只有 4 行模块声明，已含在补丁里。

---

## 1. 为什么是"新增空间域"而不是"加个开关"

读 `ARCHITECTURE.md` §2 定了调：

> 引擎内部一律 **F32 单声道 48 kHz**，10 ms hop（480）；设备原生格式只在平台层转换。

而 `audio/playback.rs` 的 `build_stream` 把同一个采样**复制到所有声道**：

```rust
for f in data.chunks_exact_mut(ch) {
  let v = <T as FromSample<f32>>::from_sample_(s);
  for x in f.iter_mut() { *x = v; }   // ← 单声道复制成 N 声道
}
```

也就是说：**现有输出端没有"声道"这个概念**，只有"单声道复制"。虚拟 7.1 要的是
「8 条互不相同的通道 → 用 HRIR 折成 2 条」——这是**另一种汇（sink）**，不是一种效果器。

同样的结论在 `engine/stage.rs` 得到二次确认：

```rust
fn process(&mut self, frame: &mut [f32], ctx: &FrameContext) -> Result<(), StageError>;
```

`Stage` 是**就地、定长、单声道**的，2 声道输出塞不进去。所以空间域只能落在
**输出行**上，而不是 `Process` 行上 —— 这也是本方案把 `spatial_output` 做成 `NodeKind::Output` 的原因。

---

## 2. 需求 → 实现的映射

| 外挂链路里的东西 | 在 PureVox 里变成 | 代码位置 |
| --- | --- | --- |
| HeSuVi：HRIR 卷积 7.1→双耳 | `MatrixConv`（8 进 2 出，分块 FFT，块长 480 / NFFT 960） | `dsp/surround/conv.rs` |
| HeSuVi：HRIR 库（`hrir/*.wav`） | 16 声道 WAV 规范 + 解析/归一/诊断 | `dsp/surround/hrir.rs`、`wav.rs` |
| APO：`Channel: BL` + `Preamp: +6 dB` | 每声道增益 `g₁…g₈`（对角阵 G，**卷积之前**） | `dsp/surround/spatial.rs` |
| APO：`Copy: L = 1.0*L + 0.8*BL` | `MixMatrix`（8×8 混音矩阵，含 APO 赋值语义） | `dsp/surround/mod.rs`、`compat/apo.rs` |
| APO：`Filter: ON PK Fc …` | 解析成 `ApoFilter`，落地到既有 `eq31`（EQ 只有一个实现） | `compat/apo.rs` |
| VB-Cable：8 声道端点 | L0 设备层 + `Sink::Stereo`（见 `PATCH.md` §2）；**也可以完全不要**，改走系统 spatializer（见 `DOLBY.md`） | 待改 `audio/playback.rs` |
| 延迟（APO 10 ms vs 本方案 45 ms） | 延迟预算模型 + 三档预设 + 块长可配（480→64） | `dsp/surround/latency.rs`、`spatial.rs` |
| Dolby Access 共存 | 8 声道旁路（`process_bed`，不卷积）→ 交给 Dolby 做双耳化 | `dsp/surround/spatial.rs`、`DOLBY.md` |

**"集合"的解释**：不是去加载 APO 的 DLL（要装驱动、要管理员、Windows 专属），
而是把它的**配置语义**翻译成引擎参数 —— 用户现成的 `config.txt` 原样导入，
链路却跑在 PureVox 内部，一份 GPL 代码、跨平台、可单测。

---

## 3. 已经交付并通过验证的部分（L1 DSP）

```
src-tauri/src/dsp/surround/
├── layout.rs   7.1 通道序 / WAVE 掩码 0x63F / 方位角（唯一事实来源）
├── wav.rs      RIFF 解析（PCM16/24/32、float32/64、EXTENSIBLE + 通道掩码）
├── hrir.rs     16 声道 HRIR 矩阵：加载 / 归一 / 双耳平衡诊断
├── conv.rs     8×2 分块卷积（uniformly-partitioned overlap-save）
├── spatial.rs  上混/8 路直入 → 每声道增益+延时 → 卷积 → 双耳；`process_bed` 走 8 声道旁路
├── latency.rs  端到端延迟预算：五段拆解 + 三档预设 + 竞技判定
└── mod.rs      MixMatrix（8×8）/ SurroundSetup / 自检
src-tauri/src/compat/
├── mod.rs
└── apo.rs      Equalizer APO config.txt 解析 + 回写（含 hesuvi.txt 的语法）
```

### 验证结果（本机实跑）

```
$ cd verify && cargo test
test result: ok. 48 passed; 0 failed

$ cargo clippy --all-targets -- -D warnings
Finished (0 warnings)          # 与仓库 CI 门禁同参数

$ cargo fmt -- --check
（无输出）                      # 用仓库自己的 rustfmt.toml（2 空格 / 100 列 / edition 2024）
```

`verify/` 是个**验证壳**：用 `#[path]` 把上面同一份 `.rs` 装进一个不依赖 Tauri 的 crate，
所以 `cargo run --bin audition` 生成的 WAV 与将来接进 app 后的输出是同一份算法的产物，
只补 `SAMPLE_RATE`/`HOP` 两个常量。交付的代码和跑测试的代码是**同一份**，不存在复制漂移。

### 48 个测试覆盖了什么

| 关注点 | 测试 |
| --- | --- |
| 分块 FFT == 直接卷积（含非整块抽头） | `partitioned_matches_direct_convolution`（误差 < 2e-5） |
| 零延迟 / 单位冲激直通 | `identity_hrir_passes_signal_through` |
| 换预设不留旧尾巴 | `reset_clears_tail` |
| 每方向增益只影响该方向 | `per_channel_gain_only_affects_that_direction`、`muting_a_channel_removes_its_contribution` |
| 真 7.1 输入（8 路平面）走同一条增益路径 | `planar_input_keeps_real_directions`、`planar_short_input_is_zero_padded` |
| 延时按样本精确位移 | `delay_shifts_signal_in_time` |
| 上混（等功率 / spread） | `upmix_front_is_equal_power`、`upmix_wide_respects_spread` |
| **换块长不改声音**（64/128/256 逐样本一致） | `block_size_does_not_change_output` |
| **块长不引入算法延迟**（16/64/128/480） | `small_block_adds_no_algorithmic_latency` |
| 块长边界（480 可用 / 8 拒绝） | `engine_hop_480_is_accepted`、`tiny_block_is_rejected` |
| **8 声道旁路**（不卷积、与 HRIR 无关、增益与延时仍精确） | `bed_path_is_sample_aligned_and_gain_only`、`bed_path_applies_per_channel_gain`、`bed_path_ignores_delay_block_boundary` |
| 延迟预算（分段求和 / 预设递减 / 对标实测 45 ms） | `stages_sum_to_total`、`presets_are_ordered_by_latency`、`current_chain_matches_observed_40_to_50ms` |
| 16 声道 → (in, ear) 映射 | `maps_channel_to_in_ear` |
| WAV 边界（截断、非 WAV、采样率） | `wav::tests::*`、`rejects_wrong_channel_count_and_rate` |
| APO 语法（Preamp/Channel/Copy/Filter/Include） | `apo::tests::*` |
| APO 导入→导出→再导入 一致 | `export_roundtrips` |

---

## 3.5 两个新需求（延迟 / Dolby）

- **延迟**：现状 45 ms 不是卷积的锅（卷积块只占 10 ms），是"虚拟声卡 + 采集"这一趟。
  四条斧子砍下去 → 13.7 ms（保留自定义 HRIR）或 11 ms（双耳化交给系统）。
  完整拆解与实测 CPU 见 [`LATENCY.md`](LATENCY.md)。
- **Dolby Access**：能共存，但要换角色——让 Dolby 做双耳化与它的 EQ，PureVox 只做每声道增益/路由
  （`Spatial::process_bed`）。两个 HRTF 串起来不是更好，是更糊。见 [`DOLBY.md`](DOLBY.md)。

## 4. 三个必须知道的物理事实（不是实现选择）

1. **增益必须加在卷积之前**。卷积后 8 路已求和成 2 路，`H·G·x = (H·G)·x`，但反过来不成立：
   求和不可逆。所以 `Spatial` 的顺序是 `上混 → G → 延时 → 卷积`，代码里注释标了"顺序不可交换"。
2. **单声道源没有方位信息**。PureVox 的 loopback 采集是**下混到单声道**的，所以现在只能
   "把一个单声道铺到 7.1"（`Upmix`），铺出来的方位是**假的**——听起来像房间，不是"敌人在左后方"。
   要真正复刻 ArtIsWar 的效果，必须让 loopback 保留 8 声道 ——
   DSP 侧已经留好入口 `Spatial::process_planar`（8 路平面输入，走同一条增益/卷积路径），
   只差采集端（`capture.rs`）保住 8 声道。
3. **HRIR 是数据，不是代码**。Dolby/DTS 等商业算法的 HRIR 不可随 GPL 源码分发，
   只能用户自行导入（`LICENSE-THIRD-PARTY.txt` 需加一条）。

---

## 5. 目录

```
PureVox-surround/
├── README.md                 ← 本文件
├── MERGE.md                  ← 下载 / 合并 / 编译 / 测试 / 排错
├── LATENCY.md                ← 延迟：45 ms 拆解、四条斧子、实测 CPU
├── DOLBY.md                  ← 与 Dolby Access 共存：三种分工 + 三个待验证实验
├── PATCH.md                  ← 集成补丁（现有文件怎么改，逐处锚点）
├── apply.sh / apply.ps1      ← 一键合并（幂等）
├── patch/*.patch             ← git apply 用
├── src-tauri/src/…           ← 新增文件，可直接复制进仓库同路径
└── verify/                   ← 独立验证壳（cargo test / clippy / fmt / 三个 bin：延迟、CPU、可听演示）
```

## 6. 下一步（P2 起的排期建议）

| 阶段 | 内容 | 前置 |
| --- | --- | --- |
| **P2** | `audio/playback.rs` 支持 `Sink::Stereo`；设备池/混音器按汇类型相加；`spatial_output` 输出行接入 session | 需要能在 Windows 上跑真机（听感 + 时钟伺服） |
| **P3** | `ui/spatial.js` 面板（雷达 + 8 推子 + HRIR 选择 + 导入 config.txt）、`/debug` 每声道电平 | 需要 HRIR 样本文件才能验证导入顺序 |
| **P4** | VB-Cable 端点检测/8ch 格式设置/安装引导 | **需实测** VB-Cable 是否真的暴露 8 声道端点 |
| **P2+** | 8 声道 loopback 采集（保住游戏原始 7.1） | 见 §4.2 |
| **P2++** | 延迟三档落地：`Sink::Stereo` 用 `IAudioClient3` 最小周期、块长 128/64、`process_bed` 直通 | 见 `LATENCY.md` §5（三件必须在 Windows 验证的事） |
| **P5** | 8 声道 bed 输出（`ISpatialAudioClient`）或 APO 形态 | 见 `DOLBY.md` 的三个实验；实验 2 决定要不要继续留 VB-Cable |
