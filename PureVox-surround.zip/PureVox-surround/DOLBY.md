# 和 Dolby Access 共存：能做什么，不能做什么

结论先给：**能共存，但必须先定一件事——双耳化由谁做。**

Dolby Atmos for Headphones 的本质是"一个装在音频端点上的 spatializer APO，把 7.1/对象音频渲染成双耳"。
PureVox 的 P1 也在做同一件事（HRIR 卷积 → 双耳）。**两个 HRTF 串起来 = 双重双耳化**，
结果不是更好，是更糟：声场变窄、定位发糊、低频叠加。

所以不是"能不能兼容"的问题，是"分工怎么切"的问题。三个切法：

---

## A. 分工串联（推荐）

```
游戏 8ch ──► PureVox（只做每声道增益 / EQ / 延时）──► 8ch ──► Dolby spatializer ──► 双耳
                        ▲                                        ▲
                   "单独调各方向音量"                      HRTF + Dolby 的 EQ / 电平
```

PureVox 只负责它**独有**的能力（每方向音量、路由、Preamp），把"听起来像不像 7.1"交给 Dolby。
两边的强项都不浪费，也不会打架。

代码里已经就位：**`Spatial::process_bed`** —— 只做 `y = G·x`（增益 + 延时），**不卷积**，输出 8 声道原样交出去。
延迟因此是 11 ms 级（见 `LATENCY.md` 第四行），和 Equalizer APO 同档。

两种落地方式，差别在"谁来喂 Dolby"：

| 方式 | 做法 | 优点 | 风险 |
|---|---|---|---|
| **A1 输出 8ch 到物理端点** | 端点开 spatial sound，PureVox 用 8 声道格式打开它 | 零驱动、零虚拟声卡、代码最少 | 需要端点接受 8ch 流（见下方实验 2） |
| **A2 `ISpatialAudioClient` 床声道** | 激活 8 个 bed 对象（`AudioObjectType_FrontLeft` … `BackRight`），逐帧写 PCM | Windows 的"正规"通道，天然交给当前 spatializer，不依赖端点格式协商 | 要用 `windows` crate 写 COM；周期由引擎给（通常 10 ms） |

两条都不需要 VB-Cable。**这是这一轮最重要的结论**：为了"分方向音量"而搭一条虚拟声卡，
付出的是 15 ms 延迟和一整套安装步骤；而 Windows 本身就有把 8 声道喂给 spatializer 的官方通道。

## B. 同链 APO（高风险，先别做）

把 PureVox 做成 APO 装在**同一个端点**上，和 Dolby 的 spatializer 同在 audiodg 的 APO 链里。

- 理论上顺序是确定的：pre-mix APO（按流）→ 混音 → post-mix APO / spatializer（按端点）。
- 实际上：**开启 spatial sound 后，端点上的第三方 APO 有被绕过的报告**，且随 Windows 版本 / 驱动行为变化。
  这也是网上"装了 Equalizer APO 但一开 Atmos 就没效果"的来源。

收益是"连采集都没有"（延迟 = 一个周期），代价是可行性不确定 + 要写 COM DLL + 调试 audiodg（受保护进程）。
→ 归到 P5，且**必须先做实验 1** 确认在你的机器上到底绕不绕。

## C. 完全替代（现状）

内置 HRIR 自己卷积，Dolby 关掉。优点是跨平台、可换 HRIR（ArtIsWar 那套就是 HeSuVi 抓的 Dolby 曲线）。
缺点是"音色是另一套"，而且和"用户已经买了 Dolby 并且喜欢它的 EQ"这个事实冲突。

对已经付过 Dolby 授权的人来说，C 是退步，不是升级。

---

## 不能做的（别在这上面浪费时间）

| 想法 | 为什么不行 |
|---|---|
| 调 Dolby 的 EQ / 读它的当前曲线 | Dolby Access 的 EQ（Music/Movie/Game/Voice、Custom EQ、Volume Leveler）全在它闭源 DSP 内部，**没有公开 API**，也没有注册表明文可读 |
| 拿 Dolby 的 HRIR | 闭源。HeSuVi 里那些"Dolby Atmos"HRIR 是**逆向测量**出来的近似，不是原厂数据 |
| 让 Dolby 处理 PureVox 的对象 | Dolby 的渲染入口是 Windows spatial 通道；想给它送对象，就得走 A2 的 `ISpatialAudioClient`，送的是 bed/object，不是"PureVox 的私有格式" |
| 捆绑分发 Dolby | 需要用户自己的 Microsoft Store 授权（付费/试用），PureVox 只能"检测到就用"，不能打包 |

---

## 产品上应该怎么呈现

一个开关，三个值，互斥，不需要用户理解原理：

```text
双耳化后端：  ● 内置 HRIR（PureVox 自己渲染）
             ○ 系统 spatializer（Dolby Atmos / Windows Sonic / DTS）
             ○ 关闭（纯 8 声道直通）
```

规则写死在代码里，别让用户踩坑：

1. 选"系统 spatializer" 时，**强制关掉卷积**，走 `process_bed`。
   （两条路径同时开 = 双重 HRTF，必须物理上不可能。）
2. 检测到端点已启用 spatial sound 且后端选了"内置"→ 弹提示："检测到 Dolby Atmos 已开启，
   两者同时开启会让定位变糊，已切到直通模式"，并**自动切换**（可撤销）。
3. 选"系统 spatializer" 时，PureVox 的 EQ 默认置平并灰掉，避免和 Dolby 的 EQ 两级叠加。
   想叠加也可以，但要显示"当前为两级 EQ 串联"。

对应代码：`Spatial::process_bed`（直通）、`Spatial::with_block(..., 0)` 无意义 → 用 `process_bed` 而不是传 0；
`latency::Preset::Competitive` 就是"后端 = 系统 spatializer"这一档的延迟模型。

---

## 三个必须在你机器上做的实验

我这边没有 Windows + 声卡 + Dolby 授权，这三条**只能你测**，但每条都只要五分钟，而且结论是二值的。

### 实验 1：spatial sound 开启时，第三方 APO 还在不在？

1. 装 Equalizer APO 到耳机端点，`config.txt` 写 `Filter: ON PK Fc 80 Hz Gain -20 dB`（低频砍 20 dB，一耳朵能听出来）；
2. 关 spatial sound → 听低频是否变薄（应该变薄）；
3. 开 Dolby Atmos for Headphones → 再听。

- 低频**仍然薄** → APO 没被绕过 → 路径 B 可行（PureVox 可以做 APO 与 Dolby 同链）。
- 低频**回来了** → 被绕过 → 路径 B 死路，只能走 A。

### 实验 2：端点开 spatial 时，还收不收 8 声道流？

1. 端点设默认、开 Dolby Atmos；
2. 用任意 8 声道播放器（或 PureVox 调试接口）往该端点输出 7.1，**单独**只给 BL 通道送一段噪声；
3. 听声音是从后方来的，还是从正前方/两侧挤出来的。

- 后方 → 8ch 被完整交给了 Dolby → **A1 可行，整条方案不需要 VB-Cable**。
- 不是后方 → Windows 提前下混了 → 只能走 A2（`ISpatialAudioClient` 床声道）。

### 实验 3：`ISpatialAudioClient` 的床对象与周期

写二十行 Rust（`windows` crate，`Windows::Win32::Media::Audio`）：

1. 取默认渲染端点的 `ISpatialAudioClient`；
2. 激活 8 个 bed 对象（FL/FR/FC/LFE/BL/BR/SL/SR），打印每个 `ActivateSpatialAudioObject` 的返回值；
3. 打印 `GetMaxFrameCount(&format)` 的帧数。

- 8 个全成功、帧数 = 480 → A2 可用，周期 10 ms，延迟模型取 `in_process(0)` = 11 ms；
- 部分失败 → Windows 版本或端点不支持该 bed 组合，退回 A1 或 C。

---

## 一句话回答

**能兼容，但角色要换**：Dolby 已经是最好的"双耳化 + EQ"，
PureVox 就别再抢这块，专做它做不到的"每声道增益 / 路由 / 配置迁移"。
这样两边叠加是加法（延迟 11 ms，音质不降），抢着做才是减法（双重 HRTF，定位变糊）。
